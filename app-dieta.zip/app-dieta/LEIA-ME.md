# App Dieta — como gerar e instalar o APK

O app já vem com a sua dieta (Versão 1.0) carregada. Tudo fica salvo no próprio celular e funciona sem internet.

O APK é gerado de graça pelo GitHub, com uma automação que já está pronta neste projeto. Você só faz isso uma vez. Depois, para atualizar o app, é só enviar os arquivos novos.

---

## 1. Criar o repositório no GitHub (no computador)

1. Crie uma conta em **github.com** (se ainda não tiver).
2. Clique em **New repository**.
   - Nome: `app-dieta`
   - Pode deixar **Private**
   - Marque **Add a README file**
   - Clique em **Create repository**

## 2. Enviar os arquivos

1. Descompacte o `app-dieta.zip` no computador.
2. No repositório, clique em **Add file › Upload files**.
3. Arraste **todo o conteúdo** da pasta `app-dieta` (as pastas `assets`, `resources`, `scripts`, `src`, `www` e os arquivos `package.json`, `capacitor.config.json`, `plano-inicial.txt`, `LEIA-ME.md`).
4. Clique em **Commit changes**.

## 3. Criar a automação que gera o APK

O GitHub às vezes não envia pastas que começam com ponto. Por isso, crie esse arquivo à mão:

1. **Add file › Create new file**
2. No nome do arquivo, digite exatamente: `.github/workflows/build-apk.yml`
3. Abra o arquivo `.github/workflows/build-apk.yml` do zip (com o Bloco de Notas), copie tudo e cole.
4. Clique em **Commit changes**.

## 4. Esperar o APK ficar pronto (uns 5–8 minutos)

1. Vá na aba **Actions**. Vai aparecer "Gerar APK" rodando (bolinha amarela).
2. Quando ficar com o ✓ verde, vá na página inicial do repositório.
3. À direita, em **Releases**, clique em **Dieta 1.0.x**.
4. Baixe o arquivo **Dieta-1.0.x.apk**.

> Dica: faça o login no GitHub pelo navegador do celular e baixe direto nele.

## 5. Instalar no celular

1. Abra o arquivo `.apk` baixado.
2. O Android vai pedir para **permitir instalar apps desta fonte** → permita.
3. Instale e abra o **Dieta**.
4. Na primeira abertura, **permita as notificações**.
5. Em **Alertas**, se aparecer "Ativar alarmes no horário exato", toque e ative. Sem isso o Android pode atrasar os avisos alguns minutos.
6. Toque em **Testar notificação** para ver como chega.

### Celulares Xiaomi, Motorola, Samsung (economia de bateria)
Alguns Androids "matam" alarmes de apps para economizar bateria. Se algum aviso não chegar:
- Configurações › Apps › Dieta › Bateria → **Sem restrições**
- Xiaomi: também ative **Início automático**.

---

## Atualizar a dieta

Não precisa mexer no código: no app, vá em **Plano › Novo plano** (ou **Ajustes › Atualizar plano de dieta**), cole o texto ou escolha o PDF que o GPT mandar, confira o resumo e salve. Dá para trocar agora ou deixar para começar na próxima segunda.

Use o botão **Copiar** em "Pedir a atualização ao GPT": ele copia um pedido que faz o GPT manter o formato que o app entende.

## Atualizar o app (versão nova)

Envie os arquivos novos para o repositório (Upload files). O GitHub gera um APK novo sozinho. Instale por cima — **seus dados continuam**.

> Faça um backup antes (Ajustes › Fazer backup) por segurança.

## O que tem em cada pasta

| Pasta / arquivo | O que é |
|---|---|
| `src/app.html` | O app inteiro (telas, regras, notificações) |
| `plano-inicial.txt` | Sua dieta inicial — o app lê esse texto na primeira abertura |
| `www/` | Versão pronta do app (gerada a partir dos dois acima) |
| `assets/` | Ícone e tela de abertura |
| `resources/` | Ícone da notificação e som silencioso (modo "só vibrar") |
| `scripts/` | Montagem do app e ajustes do Android |
| `.github/workflows/build-apk.yml` | Automação que gera o APK |
