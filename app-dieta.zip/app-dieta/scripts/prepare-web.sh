#!/usr/bin/env bash
# Copia bibliotecas e fontes para dentro de www/ (o app funciona 100% offline)
set -euo pipefail
python3 scripts/build.py
mkdir -p www/vendor www/fonts
cp node_modules/@capacitor/core/dist/capacitor.js www/vendor/capacitor.js
cp node_modules/@capacitor/local-notifications/dist/plugin.js www/vendor/local-notifications.js
cp node_modules/pdfjs-dist/build/pdf.min.mjs node_modules/pdfjs-dist/build/pdf.worker.min.mjs www/vendor/
for w in 400 500 600 700; do cp node_modules/@fontsource/barlow/files/barlow-latin-$w-normal.woff2 www/fonts/; done
cp node_modules/@fontsource/barlow-condensed/files/barlow-condensed-latin-800-normal.woff2 www/fonts/
cp node_modules/@fontsource/barlow-condensed/files/barlow-condensed-latin-800-italic.woff2 www/fonts/
cp node_modules/@fontsource/barlow-condensed/files/barlow-condensed-latin-900-italic.woff2 www/fonts/
ls -la www www/vendor www/fonts
