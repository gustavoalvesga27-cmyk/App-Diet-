#!/usr/bin/env bash
# Ajustes no projeto Android gerado pelo Capacitor
set -euo pipefail
M=android/app/src/main/AndroidManifest.xml
add_perm () {
  grep -q "$1" "$M" || sed -i "s#<application#<uses-permission android:name=\"$1\" />\n    <application#" "$M"
}
add_perm android.permission.POST_NOTIFICATIONS
add_perm android.permission.SCHEDULE_EXACT_ALARM
add_perm android.permission.RECEIVE_BOOT_COMPLETED
add_perm android.permission.VIBRATE
add_perm android.permission.WAKE_LOCK
mkdir -p android/app/src/main/res/raw android/app/src/main/res/drawable
cp resources/silencio.wav android/app/src/main/res/raw/silencio.wav
cp resources/ic_stat_dieta.png android/app/src/main/res/drawable/ic_stat_dieta.png
VER="${APP_VERSION:-1.0}"
CODE="${APP_CODE:-1}"
sed -i -E "s/versionName \"[^\"]*\"/versionName \"$VER\"/; s/versionCode [0-9]+/versionCode $CODE/" android/app/build.gradle
echo "Manifest:"; cat "$M"
