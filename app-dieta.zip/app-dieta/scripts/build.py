#!/usr/bin/env python3
"""Gera www/index.html a partir de src/app.html + plano-inicial.txt"""
import pathlib
root = pathlib.Path(__file__).resolve().parent.parent
src = (root / 'src' / 'app.html').read_text(encoding='utf-8')
plano = (root / 'plano-inicial.txt').read_text(encoding='utf-8').replace('</script', '<\\/script')
(root / 'www').mkdir(exist_ok=True)
(root / 'www' / 'index.html').write_text(src.replace('<!--PLANO_INICIAL-->', plano), encoding='utf-8')
print('www/index.html gerado')
